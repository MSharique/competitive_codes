#include<iostream>
#include<cstdio>
#include<fstream>
#include<algorithm>
#include<string>
#include<cstring>
#include<vector>
#include<sstream>
using namespace std;

vector<string> vec;
string arr[8] = {"bf" , "kmp" , "tw" , "so" , "raita" , "skip" , "kmpskip" , "askip"};

int main()
{
	int cnt = 0,temp=1;
	ifstream myfile("world192.csv");
	ofstream outfile("output.csv");
	outfile<<"text,";
		
	for(int i=0;i<18;i++)
	{
		outfile<<temp<<",";
		temp = temp * 2;
	}outfile<<endl<<"pattern"<<endl;
	
	temp = 1;
	outfile<<temp<<",";
	
	int it = 1;
	while(it < temp)outfile<<" ," , it = it *2;
	
	int avg_cnt = 18;
	string str;
	for(int i=0;;i++)
	{
		myfile>>str;
		//cout<<str<<"\n";
			
		if(str=="Average")
		{
			
			myfile>>str;
		//	cout<<str<<endl;
			myfile>>str;
		//	cout<<str <<endl;
  			stringstream ss(str); 
  			string tok;
  			it = 0;
  			while(getline(ss, tok,','))
  			{
  				if(it%2==0)vec.push_back(tok);
  				it++;
  			}
			cout<<"\n all numbers : ";
			for(int j=0;j<vec.size();j++)cout<<vec[j]<<" ";cout<<endl;
			str = *min_element(vec.begin(),vec.end());
			cout<<"\n mini : "<<str<<endl;
			//break;
			for(int j=0;j<vec.size();j++)
			{
				if(vec[j]==str)
				{
					cout<<arr[j]<<" / ";
					outfile<<arr[j]<<"/";
				}
			}
			cout<<endl;
			outfile<<",";
			vec.clear();
			cnt++;
		}
		if(cnt==avg_cnt)
		{
			avg_cnt--;
			cnt = 0;
			temp = temp*2;
			outfile<<endl;
			if(temp==4096)break;
			outfile<<temp<<",";
			int it = 1;
			while(it < temp)outfile<<" ," , it = it *2;
		
		}
	//	temp = temp * 2;
	}
	cout<<"\n cnt = "<<cnt<<endl;
	vec.clear();
	myfile.close();
	return 0;
}
